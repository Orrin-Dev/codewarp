import { spriteShapeSvg } from '@codewarp/core';
import { VmHost, type SpriteImage } from './vmHost';
import { BlocksEditor } from './blocksEditor';
import { SpritePanel } from './spritePanel';
import { MonitorOverlay } from './monitors';
import { attachStageInput } from './stageInput';

const $ = <T extends HTMLElement>(id: string): T => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`Missing element #${id}`);
  return el as T;
};

const statusEl = $('status');
const setStatus = (text: string) => {
  statusEl.textContent = text;
};

// Surface any error on screen instead of leaving the status stuck.
window.addEventListener('error', (e) => setStatus(`Error: ${e.message}`));
window.addEventListener('unhandledrejection', (e) =>
  setStatus(`Error: ${(e.reason && e.reason.message) || String(e.reason)}`),
);

/** Pick a file in the browser's own dialog (works in Electron too). */
function pickFile(accept: string): Promise<File | null> {
  return new Promise((resolve) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = accept;
    input.addEventListener('change', () => resolve(input.files?.[0] ?? null));
    input.addEventListener('cancel', () => resolve(null));
    input.click();
  });
}

function downloadInBrowser(name: string, data: Uint8Array): void {
  const url = URL.createObjectURL(new Blob([data as BlobPart], { type: 'application/x.scratch.sb3' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}

/** Read an image file and work out its format and pixel size. */
async function readSpriteImage(file: File): Promise<SpriteImage> {
  const lower = file.name.toLowerCase();
  const ext: SpriteImage['ext'] = lower.endsWith('.svg') ? 'svg' : lower.endsWith('.png') ? 'png' : 'jpg';
  if (!/\.(svg|png|jpe?g)$/.test(lower)) throw new Error('Use a .png, .jpg or .svg image');

  const data = new Uint8Array(await file.arrayBuffer());
  const mime = ext === 'svg' ? 'image/svg+xml' : ext === 'png' ? 'image/png' : 'image/jpeg';
  const url = URL.createObjectURL(new Blob([data as BlobPart], { type: mime }));
  try {
    const size = await new Promise<{ width: number; height: number }>((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve({ width: img.naturalWidth || 64, height: img.naturalHeight || 64 });
      img.onerror = () => reject(new Error(`Could not read ${file.name} as an image`));
      img.src = url;
    });
    return { data, ext, ...size };
  } finally {
    URL.revokeObjectURL(url);
  }
}

// Fill / outline pairs for new shape sprites, cycled so sprites are easy to tell apart.
const SHAPE_COLORS: [string, string][] = [
  ['#ff6680', '#c93a58'],
  ['#4c97ff', '#2b6bd0'],
  ['#59c059', '#2f8f2f'],
  ['#ffab19', '#c47a00'],
  ['#9966ff', '#6c3fd1'],
];

function boot(): void {
  setStatus('Creating VM…');
  const canvas = $<HTMLCanvasElement>('stage');
  const host = new VmHost(canvas);

  setStatus('Creating blocks editor…');
  const editor = new BlocksEditor($('blocks-host'), host.vm);

  new MonitorOverlay($('monitors'), host.vm);
  attachStageInput(canvas, host.vm);
  new SpritePanel($('sprite-list'), $('sprite-props'), host, (message) => setStatus(message));

  // ---- Sprites ---------------------------------------------------------

  const spriteCount = (): number =>
    host.vm.runtime.targets.filter((t: any) => !t.isStage && t.isOriginal).length;

  $('btn-add-sprite').addEventListener('click', async () => {
    const n = spriteCount();
    const [fill, stroke] = SHAPE_COLORS[n % SHAPE_COLORS.length];
    try {
      await host.addSpriteFromImage(`Sprite${n + 1}`, {
        data: new TextEncoder().encode(spriteShapeSvg(fill, stroke)),
        ext: 'svg',
        width: 64,
        height: 64,
      });
    } catch (error: any) {
      console.error(error);
      setStatus(`Could not add sprite: ${error?.message ?? error}`);
    }
  });

  $('btn-upload-sprite').addEventListener('click', async () => {
    const file = await pickFile('.png,.jpg,.jpeg,.svg');
    if (!file) return;
    try {
      const image = await readSpriteImage(file);
      const baseName = file.name.replace(/\.[^.]+$/, '') || `Sprite${spriteCount() + 1}`;
      await host.addSpriteFromImage(baseName, image);
      setStatus(`Added ${baseName}`);
    } catch (error: any) {
      console.error(error);
      setStatus(`Could not add sprite: ${error?.message ?? error}`);
    }
  });

  // ---- Project open / save / new ---------------------------------------

  let projectName = 'project.sb3';

  $('btn-new').addEventListener('click', async () => {
    await host.newProject();
    projectName = 'project.sb3';
    setStatus('New project');
  });

  $('btn-open').addEventListener('click', async () => {
    let picked: { name: string; data: Uint8Array } | null;
    if (window.codewarp) {
      picked = await window.codewarp.openProject();
    } else {
      const file = await pickFile('.sb3');
      picked = file ? { name: file.name, data: new Uint8Array(await file.arrayBuffer()) } : null;
    }
    if (!picked) return;
    const buffer = picked.data.buffer.slice(
      picked.data.byteOffset,
      picked.data.byteOffset + picked.data.byteLength,
    ) as ArrayBuffer;
    try {
      await host.load(buffer);
      projectName = picked.name;
      setStatus(`Opened ${picked.name}`);
    } catch (error) {
      console.error(error);
      setStatus(`Failed to open ${picked.name}`);
    }
  });

  $('btn-save').addEventListener('click', async () => {
    const bytes = await host.saveSb3();
    if (window.codewarp) {
      const savedTo = await window.codewarp.saveProject(projectName, bytes);
      if (savedTo) setStatus(`Saved ${savedTo}`);
    } else {
      downloadInBrowser(projectName, bytes);
      setStatus(`Downloaded ${projectName}`);
    }
  });

  // ---- Run controls -----------------------------------------------------

  $('btn-flag').addEventListener('click', () => host.greenFlag());
  $('btn-stop').addEventListener('click', () => host.stopAll());

  // ---- Mode toggle (text mode is a read-only preview for now) -----------

  const blocksHost = $('blocks-host');
  const textHost = $<HTMLTextAreaElement>('text-host');
  const modeBlocks = $('mode-blocks');
  const modeText = $('mode-text');

  function showBlocks(): void {
    textHost.hidden = true;
    blocksHost.hidden = false;
    modeBlocks.classList.add('active');
    modeText.classList.remove('active');
    editor.resize();
  }

  function showText(): void {
    // Placeholder: the C#-style and Python-style printers will render here later.
    textHost.value = JSON.stringify(host.editingTargetJson(), null, 2);
    blocksHost.hidden = true;
    textHost.hidden = false;
    modeText.classList.add('active');
    modeBlocks.classList.remove('active');
  }

  modeBlocks.addEventListener('click', showBlocks);
  modeText.addEventListener('click', showText);

  // ---- Load the starting project ----------------------------------------

  setStatus('Loading project…');
  const hangTimer = window.setTimeout(
    () => setStatus('Project load is taking too long (open DevTools: Ctrl+Shift+I)'),
    8000,
  );

  host
    .newProject()
    .then(() => {
      window.clearTimeout(hangTimer);
      setStatus('Ready');
    })
    .catch((error) => {
      window.clearTimeout(hangTimer);
      console.error(error);
      setStatus(`Load failed: ${error?.message ?? error}`);
    });
}

try {
  boot();
} catch (error: any) {
  console.error(error);
  setStatus(`Startup failed: ${error?.message ?? error}`);
}
